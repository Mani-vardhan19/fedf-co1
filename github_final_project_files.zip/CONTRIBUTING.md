# Contributing Guidelines

Thank you for your interest in contributing to this project!

## How to Contribute
1. **Fork** the repository.
2. **Clone** your fork locally:
   ```bash
   git clone https://github.com/<your-username>/<repository-name>.git
   ```
3. **Create a new branch** for your feature or fix:
   ```bash
   git checkout -b feature-name
   ```
4. **Make your changes** and **commit**:
   ```bash
   git commit -m "Add feature-name"
   ```
5. **Push** your branch:
   ```bash
   git push origin feature-name
   ```
6. **Create a Pull Request** on GitHub.

## Code Style
- Use clear commit messages.
- Keep scripts simple and well-commented.
- Test your changes before submission.

## Reporting Issues
Please open an issue in the repository to report bugs or suggest enhancements.
