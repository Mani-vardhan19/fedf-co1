# Simple Interest Calculator

This project calculates **simple interest** using a shell script.

## 📘 Project Overview
The repository demonstrates basic Git and GitHub operations, including:
- Repository creation
- Adding license and documentation files
- Using branches and pull requests
- Writing a simple Bash script

## 💻 Script Usage
The file `simple-interest.sh` calculates simple interest based on:
```
Simple Interest = (Principal * Rate * Time) / 100
```

### Run the script:
```bash
bash simple-interest.sh
```

## 🧑‍💻 Author
Created by Your Name

## 🪪 License
This project is licensed under the Apache 2.0 License - see the [LICENSE](LICENSE) file for details.
